#include <stdio.h>
#include <assert.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define LEN 4096

/*  convert string to lowercase */
void tolowercase(char *s)
{
        size_t size = strlen(s);
	int i = 0;
	for(; i < size; i++)
	{	
		*(s+i) = tolower(*(s+i));
	}
}

/* trim off whitespace from the right */
/* see the manpage for isspace */
void rstrip(char *s)
{
        size_t size = strlen(s);
	int i = size;
	for(; i >= 0; i--)
	{
		if(isspace(*(s+i-1))){
			*(s+i-1) = '\0';
		}else{
			i = -1;
		}
	}
}

static int cmpstrings(const void *s1, const void *s2)
{
	int size = strlen((char *)s1);
	if(size > strlen((char *)s2))
		size = strlen((char *)s2);
	
	return strncmp( (char *)s1, (char *)s2, size);
}


int main(int argc, char *argv[])
{
        char buf[LEN];
	char *t = NULL;

	char **list = NULL;
	int word = 1;
	int i;
	int size = word;
	FILE *fp;

	fp = fopen(argv[1], "r");
	assert(fp);

	/* this leaks -- fix */
	while(fgets(buf, LEN, fp)) {
		/* remove new line */
		rstrip(buf); 
		tolowercase(buf);
		t = malloc((strlen(buf) + 1) * sizeof(char));
                assert(t);
		strncpy(t, buf, strlen(buf) + 1);
                /* this needs improvement */
		if(word == size){
			list = realloc(list, size * 2 * sizeof(char *)); 
			size *= 2;
		}
		list[word - 1] = t; 
		word++;
	}
        /* overcounted */
        word--;
    
        /* print the list */
	for(i = 0; i < word; i++) 
		printf("%s\n", list[i]);

        printf("\n");

	/* todo sort list with qsort()*/
	qsort(list,word , sizeof(char *), cmpstrings);

        /* print sorted list */	
        for(i = 0; i < word; i++) 
		printf("%s\n", list[i]);
	free(list);

        return 0;
}
