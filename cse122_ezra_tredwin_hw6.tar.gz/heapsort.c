#include "heapsort.h"
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void swap(char *a, char *b, size_t width)
{
	void *tmp = malloc( sizeof(char *) * width);
	memcpy(tmp, (void *)a, width);
	memcpy((void *)a, (void *)b, width);
	memcpy((void *)b, tmp, width);
	
}

void max_heapify(void *base, int i, size_t size, size_t width, int (*compar)(const void *, const void *))
{
	int lside = i * 2 + 1;
	int rside = i * 2 + 2;
	if(lside >= size)
	{
		return;
	}
	if(rside >= size){
		rside = lside;
	}
	int largest;
	if( compar((void *)((char *)base + lside * width), (void *)((char *)base + rside * width)) > 0){
		largest = lside;
	}else{ 
		largest = rside;
	}
 	if(compar( (void *)((char *)base + i * width), (void *)((char *)base + largest * width)) < 0)
	{
		
		swap(((char *)base + i * width), ((char *)base + largest * width), width);

		max_heapify(base, largest, size, width, compar);
	}
	return;
}


int heapsort(void *base, size_t nel, size_t width, int (*compar)(const void *, const void *))
{
        /* todo generic heapsort */
        /* note you have to do pointer arthimetic with void pointers */
        /* can't use array notation, base[i] as that makes no sense as base is a void pointer  */
        /* correct way to get the i-th element is (base + i * width) */
	int i = nel;
	int rside;
	int lside;
	int largest; 
	for(; i >= 0; i--)
	{
		max_heapify(base, i, nel, width, compar);
	}
	

	int size = nel;
	while(size)
	{
		swap(((char *)base), ((char *)base + (size - 1) * width), width);
		size--;
		max_heapify(base, 0, size, width, compar);
	
	}
	

        return 0;
}


