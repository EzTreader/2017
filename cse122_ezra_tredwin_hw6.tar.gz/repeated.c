#include <stdio.h>
#include <stdlib.h>
#include <string.h>




char strchrrep(char *string)
{
	int character[128] ={0};
	int i = 0;
	for( ; i < strlen(string); i++)
	{
		character[(int)*(string + i)]++;
		if(character[(int)*(string + i)] > 1)
			return *(string + i);
	}
	return '\0';
	
}

int main(int argc, char **argv)
{
        	
	if (argc != 2) {
		printf("error in input\n");
		printf("usage: ./repeated [STRING]\n");
		printf("where [STRING] is the string to find the first repeated character in\n");
		exit(EXIT_FAILURE);
	}
	char repeat;

        /* call strchrrep(argv[1]) */
	repeat = strchrrep(argv[1]);

	/* print the first repeated char in argv[1] */
	if(repeat)
		printf("first repeated character is: %c\n",repeat);
	else
		printf("no repeated characters in the string: %s\n", argv[1]);
	
	return 0;
}
