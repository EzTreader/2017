#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <assert.h>


struct word_t{

        int score;
        size_t size;
        char *word;
};

static int cmpstrings(const void *s1, const void *s2)
{
	return strcmp( *(char * const *)s1, *(char * const *)s2);
}

void * scrabble_search( struct word_t *dictionary, char *word, int size)
{
	char **array = NULL;
	array = malloc( size * sizeof(char *));
	assert(array);
	int i = 0;
	for(i = 0; i < size; i++)
	{
		array[i] = dictionary[i].word;
	}
	
        return bsearch(word, array, sizeof(char *), size, cmpstrings);
}

int find_score(char word[])
{
	int scores[] = {1,3,3,2,1,4,2,4,1,8,5,1,3,1,1,3,10,1,1,1,1,4,4,8,4,10};
	int score = 0;
	int i;
	for(i = 0;i < strlen(word);i++)
	{
		score += scores[*(word + i) - 'a'];
	}
	return score;
}

int word_check( char letters[], char word[], int size)
{
	int i, j, tmp_j;
	int letters_size = strlen(letters);
	int *used = malloc( letters_size * sizeof(int));
	for (i = 0; i < letters_size; i++)
		used[i] = 0;
	for ( i = 0; i < size; i++)
	{
		for( j = 0; j < strlen(letters); j++)
		{
			if(word[i] == letters[j])
			{
				tmp_j = j;
				j = strlen(letters) + 1;

				if(used[tmp_j])
					j = tmp_j;

			}
		}
		if(j == strlen(letters)){
			free(used);
			return 0;
		}

		used[tmp_j] = 1;
	}
	free(used);
	return 1;
}

int best_word(struct word_t *dictionary, char *letters, int size)
{
	int max_score = 0;
	int max_word = -1;
	int i;
	for(i = 0; i < size; i++)
	{
		if(dictionary[i].score > max_score)
		{
			if(word_check(letters, dictionary[i].word, dictionary[i].size))
			{
				max_word = i;
				max_score = dictionary[max_word].score;
			}
		}
	}
	return max_word;

}

void free_list(struct word_t *dictionary, int size)
{
	int i = 0;
	for(; i < size; i++)
		free(dictionary[i].word);
}

int main()
        {
        FILE *scrabble_list;
        char buf[64];
        struct word_t *dictionary = malloc(sizeof(struct word_t));
        int i = 1;
        int size;
        char *word = NULL;

        scrabble_list = fopen("scrabble.txt","r");

        while(fgets( buf, 64, scrabble_list))
        {

                dictionary = realloc(dictionary , i * sizeof(struct word_t));
		word = strtok(buf, "\n");
		dictionary[i-1].word = malloc((strlen(word) + 1) * sizeof(char));
		strncpy(dictionary[i-1].word,word,strlen(word) + 1);
		dictionary[i-1].score = find_score(dictionary[i-1].word);
		dictionary[i-1].size = strlen(dictionary[i-1].word);
                i++;


        }
        size = i;

	short quit = 1;
	short option;
	char *input;
	int best_play;
	while(quit)
	{
		printf("Scrabble Menu\n1. find if a word is in the scrabble dictionary\n2. determine best play from tiles\n 3. quit\n Enter option [1, 2, 3] : ");
		fgets(buf, 64, stdin);
		sscanf(buf, "%hd", &option);
		switch(option) {
		case 1 :
			printf("enter word :");
			fgets(buf, 64, stdin);
			sscanf(buf, "%s", input);
			if(scrabble_search( dictionary, input, size))
				printf("%s is a valid scrabble word\n", input);
			else
				printf("%s is an invalid scrabble word\n", input);
			break;
		case 2 :
			printf("enter tiles :");
			fgets(buf, 64, stdin);
			sscanf(buf, "%s", input);
			best_play = best_word( dictionary, input, size);
			printf("best play is \'%s\' (%d points)\n",dictionary[best_play].word, dictionary[best_play].score);
			break;
		case 3 :
			quit = 0;
			break;
		}

	}
	free_list(dictionary, size);
	free(dictionary);
}
