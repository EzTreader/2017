#include "stack.h"
#include <stdlib.h>
#include <assert.h>

struct stack_t {
        int count;
        struct node_t {
                void *data;
                struct node_t *next;
        } *head;
};


/** creates a new stack
 * @return stk a new stack
*/
stack new_stack(void)
{
        stack stk = malloc(sizeof(struct stack_t));
        stk->count = 0;
        stk->head = NULL;
        return stk;
}

/** pushes a data segment onto the stack
 * @param stk the stack
 * @param data the new data to push onto the stack
*/
void push(stack stk, void *data)
{
        struct node_t *node = NULL;
        node = malloc(sizeof(struct node_t));
        assert(node);
        node->data = (char *)data;
        node->next = stk->head;
        stk->head = node;
        stk->count++;
}

/** pops the top of the stack off and returns the data contained in it
 * @param stk
 * @return data the data from the top of the stack
*/
void *pop(stack stk)
{
        struct node_t *tmp;
        void *data;
        tmp = stk->head;
        stk->head = stk->head->next;
        data = tmp->data;
        stk->count--;
        free(tmp);
        return data;
}

/** looks at the top of the stack and returns the value of the data
 * @param stk the stack
 * @return stk->head->data the data from the top of the stack
*/
void *peek(stack stk)
{
        return stk->head->data;
}


/** frees a stack
 * @param stk the stack
*/
void free_stack(stack stk)
{
        struct node_t *tmp;
        while(stk->head)
        {
                tmp = stk->head;
                stk->head = stk->head->next;
                free(tmp);
        }
}

/** checks if the stack is empty
 * @param stk the stack
 * @return 1 if empty 0 if not
*/
int is_stack_empty(stack stk)
{
        if(stk->head)
                return 0;
        else
                return 1;
}

/** counts the length of the stack
 * @param stk the stack
 * @return stk->count the count of the length of the stack
*/
int stack_count(stack stk)
{
        return stk->count;
}
