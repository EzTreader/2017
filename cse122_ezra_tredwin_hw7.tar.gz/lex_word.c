#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "lex_word.h"




int get_token(FILE *input)
{
        char character;
        while((character = fgetc(input)) != EOF)
        {
                if(isalpha(character))
                {
                        return (int)character;
                }
                if(ispunct(character)){
                        return TOK_POP;
                }
                if(isspace(character)){
                        return TOK_POP;
                }

        }
        return TOK_POP;
}
