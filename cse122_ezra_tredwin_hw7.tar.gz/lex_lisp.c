#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include "lex_lisp.h"


int get_tok(FILE *file)
{
        char file_value;
        while((file_value = fgetc(file)) != EOF)
        {
                switch(file_value){
                case '(':
                        return TOK_LEFT;
                case ')':
                        return TOK_RIGHT;

                case '\n':
                        return TOK_NL;
                }
        }
        return TOK_EOF;
}
