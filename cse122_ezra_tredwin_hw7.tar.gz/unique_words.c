/**
* @file unique_words.c
* @brief check for uncommon word and there frequency
* @author Ezra Tredwin
* @date 4/23/17
* @bugs seg faults
* @todo qsort
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "stack.h"
#include "unique_words.h"
#include "lex_word.h"

struct list_t{
        int length;
        struct node_t{
                char *word;
                int frequency;
                struct node_t *next;
        }*head;
};

int main(int argc, char ** argv)
{


        FILE *common_file, *unique_file;
        common_file = fopen("1000_words.txt", "r");
        chain common_hash = malloc(250 * sizeof(struct list_t));
        char buf[128];
        char *word;
        unsigned int key;

        while(fgets(buf, 128, common_file))
        {
                word = strtok(buf, "\n");
                key = djb_hash(word);
                insert_word(word, &common_hash[key % 250]);

        }
        stack stk = new_stack();
        char *n;
        short word_building = 1, repeat = 0, quit = 1;
        int hash_size;
        printf("Enter file name");
        fgets(buf, 128, stdin);
        char *file_name = strtok(buf, "\n");
        sscanf(argv[1], "%d", &hash_size);
        chain unique_hash = malloc(hash_size * sizeof(struct list_t));
        struct node_t *tmp;
        char tok;
        unique_file = fopen(file_name, "r");
        while(quit)
        {
                while(word_building){
                        switch(tok = get_token(unique_file)){
                        case TOK_POP :
                                if(is_stack_empty(stk)){
                                        break;

                                }else{
                                        stack_pop_word(stk, word);
                                        word_building = 0;
                                }
                                break;
                        case TOK_EOF :
                                quit = 0;
                                break;
                        default :
                                n = malloc(sizeof(char));
                                *n = (char)tok;
                                push(stk, n);
                                break;
                        }
                }
                key = djb_hash(word);
                tmp = unique_hash[key % hash_size].head;
                while(tmp)
                {
                        if(!strncmp(word, tmp->word, strlen(word)) && (strlen(word) == strlen(tmp->word))){
                                tmp->frequency++;
                                repeat = 1;
                        }
                        tmp = tmp->next;
                }
                if(!repeat){
                        insert_word(word, &unique_hash[key]);
                }
                repeat = 0;

        }



}

/** pop all of the values off of a stack in reverse order
* @param stk the stack
* @param word the word to store the poped values
*/
void stack_pop_word(stack stk, char *word)
{
        word = malloc(sizeof(char) * (stack_count(stk) + 1));
        int i = 0;
        stack stk1 = new_stack();
        while(!(is_stack_empty(stk))){
                push(stk1, pop(stk));
        }

        while(!(is_stack_empty(stk1))){
                word[i] = *(char *)pop(stk1);
                i++;
        }
        word[i] = '\0';

}

/** creates a node
* @param word the word to go in the node data
* @return pointer to new node
*/
struct node_t *create_node(char *word)
{
        struct node_t *node = malloc(sizeof(struct node_t));
        assert(node);
        node->next = NULL;
        node->word = malloc(sizeof(word));
        strncpy(node->word, word, strlen(word) + 1);
        return node;
}

/** inserts a word into a list
* @param word the word
* @param list the list
*/
void insert_word(char *word, chain list)
{
        struct node_t *node = create_node(word);
        (list->length) = list->length + 1;
        node->next = list->head;
        list->head = node;
}

/** calculates an index from a pointer key value
* @param key the key value
* @return the index
*/
unsigned djb_hash( void * key )
{
        unsigned char *p = (unsigned char *)key ;
        unsigned h = 0;
        while ( *p ) {
                h = 33 * h + *p ;
                p ++;
        }
        return h ;
}

/** prints out a hash table
* @param hash the hash table
* @param tbl_size the size of the hash table
*/
void print_hash(chain hash, int tbl_size)
{
        int i = 0, j = 0;
        struct node_t *tmp;
        for(; i < tbl_size; i++)
        {
                tmp = hash[i].head;
                printf("%5d: ", i);
                while(tmp)
                {
                        printf("%s", tmp->word);
                        tmp = tmp->next;
                        if(tmp)
                                printf(", ");
			j++;
                }
                printf("\n");
        }
	printf("table size %d, load factor %d\n", tbl_size, j / i);

}
