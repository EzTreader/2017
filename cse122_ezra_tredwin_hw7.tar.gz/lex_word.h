#ifndef LEX_WORD_H
#define LEX_WORD_H

#define TOK_POP 1
#define TOK_EOF 2

int get_token(FILE *input);

#endif
