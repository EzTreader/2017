#include "lex.h"
#include "stack.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#define MAX_NUM 512   //max chars in number, increase as necessary

int calc(void)
{
        int token;
        char num[MAX_NUM];
        char c;
        stack stk1 = new_stack();
        double answer;
        double* double_num = malloc(sizeof(double));
        int i = 0;

        while (1) {
                switch (token = get_tok(num, sizeof(num))) {
                case TOK_NUM:
                        printf("TOK_NUM: %s (%lf)\n", num, strtod(num, NULL));
                        double_num[i] = atof(num);
                        double_num = realloc(double_num, sizeof(double_num) + sizeof(double));
                        push(stk1, double_num + i);
                        i++;
                        break;
                case TOK_MULT:
                        printf("TOK_MULT\n");
                        answer = *(double *)pop(stk1) * *(double *)pop(stk1);
                        push(stk1, &answer);
                        break;
                case TOK_DIV:
                        printf("TOK_DIV\n");
                         answer = (1 / *(double *)pop(stk1)) * *(double *)pop(stk1);
                         push(stk1, &answer);
                        break;
                case TOK_ADD:
                        printf("TOK_ADD\n");
                        answer = *(double *)pop(stk1) + *(double *)pop(stk1);
                        push(stk1, &answer);
                        break;
                case TOK_SUB:
                        printf("TOK_SUB\n");
                        answer =  (-1 * *(double *)pop(stk1)) + *(double *)pop(stk1);
                        push(stk1, &answer);
                        break;
                case TOK_EXP:
                        printf("TOK_EXP\n");
                        answer = pow(*(double *)pop(stk1) , *(double *)pop(stk1));
                        push(stk1, &answer);
                        break;
                case TOK_NL:
                        printf("TOK_NL\n");
                        printf("Answer = %lf\n",*(double *)(pop(stk1)));
                        return TOK_NL;
                case TOK_QUIT:
                        printf("goodbye\n");
                        exit(EXIT_SUCCESS);
                case TOK_EOF:
                        printf("TOK_EOF\n");
                        exit(EXIT_SUCCESS);
                case TOK_ERR:
                        printf("TOK_ERR\n");
                        //eat the remaining characters in stdin
                        while ((c = getchar()) != '\n')
                                c++;
                        return TOK_ERR;
                }
        }
}


int main(void)
{
        int tok = TOK_NL;
        char *prompt = "postfix> ";

        printf("Welcome to the postfix calculator\n");
        printf("Enter a postfix expression -- all expressions are converted to floating point\n");
        printf("Enter CTRL + C to quit or type \"quit\"\n");

        while (1) {
                if (tok == TOK_NL)
                        printf("%s", prompt);

                tok = calc();

                //an error occur?
                if (tok == TOK_ERR) {
                       fprintf(stderr, "error in postfix expression\n");
                       tok = TOK_NL;
                }

        }

        return 0;
}
