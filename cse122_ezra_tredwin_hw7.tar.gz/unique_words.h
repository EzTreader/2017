#ifndef UNIQUE_WORDS_H_
#define UNIQUE_WORDS_H_

#include <sys/types.h>


typedef struct list_t *chain;

struct node_t *create_node(char *word);
void insert_word(char *word, chain list);
unsigned djb_hash( void * key );
void stack_pop_word(stack stk, char *word);


#endif
