#ifndef _LEX_LISP_H_
#define _LEX_LISP_H_

#include <sys/types.h>

#define TOK_LEFT 1
#define TOK_RIGHT 2
#define TOK_NL 3
#define TOK_EOF 4

int get_tok(FILE *file);

#endif
