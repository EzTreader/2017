/**
* @file bal_paren.c
* @brief check for unmatched parenthesis in a file
* @author Ezra Tredwin
* @date 4/23/17
* @bugs none
* @todo none
*/
#include <stdio.h>
#include <stdlib.h>
#include "stack.h"
#include "lex_lisp.h"


int main(int argc, char ** argv)
{
        FILE *input = NULL;
        input = fopen(argv[1], "r");
        stack stk1 = new_stack();
        int *line_value = NULL;
        int line = 1;
        int quit = 1;

        while(quit)
        {
                switch(get_tok(input)){
                case TOK_LEFT:
                        line_value = malloc(sizeof(int));
                        *line_value = line;
                        push(stk1,  line_value);
                        break;
                case TOK_RIGHT:
                        if(is_stack_empty(stk1)){
                                printf("Unbalanced Parenthesis: ) line %d\n", line);
                        }else{
                                pop(stk1);
                        }
                        break;
                case TOK_NL :
                        line++;
                        break;
                case TOK_EOF :
                        quit = 0;
                }
        }

        while(! is_stack_empty(stk1))
        {
                printf("Unbalanced Parenthesis: ( line %d\n",*(int *)pop(stk1));
        }




}
