#ifndef AVL_H_
#define AVL_H_

typedef struct avl_node_t *AVL_T ;


int height(AVL_T root);
AVL_T single_rotate_left(AVL_T x);
AVL_T single_rotate_right(AVL_T w);
AVL_T double_rotate_right(AVL_T z);
AVL_T double_rotate_left(AVL_T z);
AVL_T insert(AVL_T root, void *key, void *data, int (compar(const void *a, const void *b)));
/* this performs a bst deletion only */
AVL_T delete_node(AVL_T root, void *key, int(compar(const void *a, const void *b)), void (free_node(void *tmp)));
AVL_T find_max(AVL_T tmp);
void inorder(AVL_T node, void (print(void *a, void *b)));
void pre_order(AVL_T node, void (print(void *a)));
void post_order(AVL_T node, void (print(void *a)));
void post_order_run(AVL_T node, void (print(void *a)));
void pre_order_run(AVL_T node, void (print(void *a)));
void inorder_run(AVL_T node, void (print(void *a, void *b)));
void delete_tree(AVL_T root, void (free_node(void *tmp)));
AVL_T avl_find( AVL_T root, void *key, int (compar( const void *a, const void *b)));



#endif
