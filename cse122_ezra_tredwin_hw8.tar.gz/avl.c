
#include "avl.h"
#include <stdlib.h>
#include <stdio.h>


struct avl_node_t {
	void *key;
	void *data;
	int height; 		/* balance factor */

	struct avl_node_t *left;
	struct avl_node_t *right;
};

int height(AVL_T root)
{
	if (!root)
		return -1;

	else
		return root->height;
}

int max(int a, int b)
{
	if (a < b)
		return b;
	else
		return a;
}


/* LL new node inserted into the left subtree of the left subtree of the critical node */
AVL_T single_rotate_left(AVL_T x)
{
	AVL_T w = x->left;
	x->left = w->right;
	w->right = x;

	x->height = max(height(x->left), height(x->right)) + 1;
	w->height = max(height(w->left), x->height) + 1;
	return w; 		/* new root */

}


/* RR new node inserted into the right subtree of the right subtree of the critical node */
AVL_T single_rotate_right(AVL_T w)
{
	AVL_T x = w->right;
	w->right = x->left;
	x->left = w;

	w->height = max(height(w->left), height(w->right)) + 1;
	x->height = max(height(x->right), w->height) + 1;
	return x; 		/* new root */

}

/* LR rotation new node inserted into the right subtree of the left subtree of the critical node  */
AVL_T double_rotate_left(AVL_T z)
{
	z->left = single_rotate_right(z->left);
	return single_rotate_left(z);
}

/* RL rotation new node inserted into the left subtree of the right subtree of the critical node  */
AVL_T double_rotate_right(AVL_T z)
{
	z->right = single_rotate_left(z->right);
	return single_rotate_right(z);
}

AVL_T insert(AVL_T root, void *key, void *data, int (compar(const void *a, const void *b)))
{
	if (!root) {
		root = malloc(sizeof(struct avl_node_t));
		if (!root) {
			printf("insert: malloc error\n");
			return NULL;
		}
		else {
			root->key = key;
			root->data = data;
			root->height = 0;
			root->left = NULL;
			root->right = NULL;
		}
	}
	else if(0 > compar(root->key, key)) { /* left subtree */
		root->left = insert(root->left, key, data, compar);
		if ((height(root->left) - height(root->right)) == 2) {
			if (0 > compar(root->left->key, key)) /* left subtree */
				root = single_rotate_left(root); /* LL */
			else 	/* LR */
				root = double_rotate_left(root);

		}
	}
	else if (0 < compar(root->key, key)) { /* right subtree */
		root->right = insert(root->right, key, data, compar);
		if ((height(root->right) - height(root->left)) == 2) {
			if (0 > compar(root->right->key, key)) /* left subtree */
				root = double_rotate_right(root); /* RL */
			else 	/* RR */
				root = single_rotate_right(root);
		}
	}

	root->height = max(height(root->left), height(root->right)) + 1;

	return root;
}


/* this is a delete for a bst not an avl tree */
/* make it an avl deletion by accounting for rotations after you delete a node */
AVL_T delete_node(AVL_T root, void *key, int(compar(const void *a, const void *b)), void (free_node(void *tmp)))
{
	AVL_T tmp;

	/* find node */
	if (root == NULL)
		printf("element not found\n");
	else if(0 > compar(root->key, key)) { /* left subtree */
		root->left = delete_node(root->left, key, compar, free_node);
	}
	else if (0 < compar(root->key, key)) { /* right subtree */
		root->right = delete_node(root->right, key, compar, free_node);
	}
	else {/* found element */
		//root->height -= 1;
		if (root->left && root->right) {
			/* two children */
			/* replace with largest in left subtree */
			/* you need to implement the find_max function */
			/* uncomment the next two lines once find_max is implemented */
			tmp = find_max(root->left);
			root->key = tmp->key;
			root->left = delete_node(root->left, root->key, compar, free_node);
		}
		else {

			tmp = root;
			/* no children */
			if (root->left == NULL && root->right == NULL)
				root = NULL;
			else if (root->left != NULL) 			/* one child */
				root = root->left;
			else
				root = root->right;

			free_node(tmp->key);
			free(tmp);
		}
	}

	/*if(root){
			root->height = max(height(root->left), height(root->right)) + 1;
		if ((height(root->left) - height(root->right)) == 2) {
			if (height(root->left->right) - height(root->left->left) == 1)
				root = double_rotate_left(root);
			else
				root = single_rotate_left(root);

		}
		if ((height(root->right) - height(root->left)) == 2) {
			if (height(root->right->left) - height(root->right->right) == 1)
				root = double_rotate_right(root);
			else
				root = single_rotate_right(root);
		}
	}
	*/
	return root;
}

void delete_tree(AVL_T node, void (free_node(void *tmp)))
{
	if(node != NULL){
		delete_tree(node->left, free_node);
		delete_tree(node->right, free_node);
		node->left = NULL;
		node->right = NULL;
		free_node(node->key);
		free(node);
		node = NULL;

	}
}

AVL_T find_max(AVL_T tmp)
{
	while(tmp->right)
		tmp = tmp->right;
	return tmp;
}


void inorder(AVL_T node, void (print(void *a, void *b)))
{
	printf("Inorder\n");
	inorder_run(node, print);
}
void inorder_run(AVL_T node, void (print(void *a, void *b)))
{
	if (node) {
		inorder_run(node->left, print);
		print(node->key, node->data);
		inorder_run(node->right, print);
	}
}

void pre_order(AVL_T node, void (print(void *a)))
{
	printf("Preorder\n");
	pre_order_run(node, print);

}
void pre_order_run(AVL_T node, void (print(void *a)))
{
	if(node){
		print(node->key);
		pre_order_run(node->left, print);
		pre_order_run(node->right, print);
	}
}

void post_order(AVL_T node, void (print(void *a)))
{
	printf("Postorder\n");
	post_order_run(node, print);
}

void post_order_run(AVL_T node, void (print(void *a)))
{
	if(node){
		post_order_run(node->left, print);
		post_order_run(node->right, print);
		print(node->key);
	}
}

AVL_T avl_find( AVL_T root, void *key, int (compar( const void *a, const void *b)))
{
	if (!root) {
		return NULL;
	}else if(0 > compar(root->key, key)) { /* left subtree */
		avl_find(root->left, key, compar);
	}
	else if (0 < compar(root->key, key)) { /* right subtree */
		avl_find(root->left, key, compar);

	}else if(compar(root->key, key) == 0){
		return root->data;
	}


}
