#include "avl.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int compar( const void *a, const void *b)
{
        return strcmp((char *)a,(char *)b);
}
void free_node( void *a)
{
        free((char *)a);
}

void print_1( void *a, void *b)
{
	printf("key = %s, data = %s\n", (char *)a, (char *)b);
}

void print_2(void *a)
{
        printf("key = %s\n", (char *)a);
}


int main()
{
        FILE *input;
        input = fopen("greek.txt", "r");
        char buf[1024];
        char *key;
        char *tok_tmp;
        char *data;
        int i = 0;
        AVL_T root = NULL;
        void *tmp = NULL;
        while(fgets(buf, 1024, input))
        {
                if(i % 2){
                        tok_tmp = strtok(buf, "\0");
                        data = malloc((strlen(tok_tmp)+ 1) * sizeof(char));
                        strncpy(data, tok_tmp, strlen(tok_tmp)+ 1);
                        root = insert(root, key, data, compar);

                }else{
                        tok_tmp = strtok(buf, "\n");
                        key = malloc((strlen(tok_tmp) + 1) * sizeof(char));
                        strncpy(key, tok_tmp, strlen(tok_tmp)+ 1);
                }
                i++;

        }
        inorder(root, print_1);
        pre_order(root, print_2);
        post_order(root, print_2);

        tmp = avl_find(root, (void *)"Dionysus", compar);
        if(tmp){
                printf("key = Dionysus, data = %s\n", (char *)tmp);
        }else{
                printf("NOT FOUND\n");
        }

        tmp = avl_find(root, (void *)"Jupiter", compar);
        if(tmp){
                printf("key = Jupiter, data = %s\n", (char *)tmp);
        }else{
                printf("NOT FOUND\n");
        }

        root = delete_node(root, (void *)"Hestia", compar, free_node);
        pre_order(root, print_2);

        delete_tree(root, free_node);

        return 0;


}
